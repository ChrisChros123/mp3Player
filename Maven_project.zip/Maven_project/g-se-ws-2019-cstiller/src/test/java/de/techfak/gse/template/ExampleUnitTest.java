package de.techfak.gse.template;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.*;

class ExampleUnitTest {

    @Test
    void unitTest() {
        Assertions.assertThat(true).isTrue();
    }
}
